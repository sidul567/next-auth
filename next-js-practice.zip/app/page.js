"use client"

import { signIn, useSession } from "next-auth/react";
import Image from "next/image";

export default function Home() {
  const {data} = useSession();
  console.log(data);
  return (
    <main>
      <button onClick={()=>signIn("google")}>Sign in with google</button>
    </main>
  );
}
